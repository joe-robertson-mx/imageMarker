//>>built
define("dijit/tree/model",["dojo/_base/declare"],function(_1){
return _1("dijit.tree.model",null,{destroy:function(){
},getRoot:function(_2){
},mayHaveChildren:function(_3){
},getChildren:function(_4,_5){
},isItem:function(_6){
},getIdentity:function(_7){
},getLabel:function(_8){
},newItem:function(_9,_a,_b,_c){
},pasteItem:function(_d,_e,_f,_10,_11,_12){
},onChange:function(_13){
},onChildrenChange:function(_14,_15){
}});
});
